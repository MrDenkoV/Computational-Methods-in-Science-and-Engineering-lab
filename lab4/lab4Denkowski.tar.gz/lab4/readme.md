Downloaded a lot of articles from wikipedia as xml and merged files into 1
Used wiki extractor - txt.py, using python txt.py tmp/Wikipedia100.xml
Ran the whole script from ipynb where at the beginning we seperate articles to seperate files in done/
